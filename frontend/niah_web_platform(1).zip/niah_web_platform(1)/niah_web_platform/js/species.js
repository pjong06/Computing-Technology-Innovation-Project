// species.js - the Species catalogue page (search, filter, add, edit, delete).
// Needs shared.js (loaded before this file).

drawMenu('species.html');


// Make one table row for one species. "index" is its position in the saved list.
function makeSpeciesRow(species, index) {
  const row = document.createElement('tr');
  row.className = 'row';

  // clicking the row opens the editor for this species
  row.onclick = function () {
    openEditorFor(index);
  };

  // first cell: photo + names
  const names = document.createElement('div');
  const scientific = document.createElement('i');
  scientific.className = 'sci';
  scientific.textContent = species.sci;
  const common = document.createElement('div');
  common.className = 'muted';
  common.textContent = species.com;
  names.appendChild(scientific);
  names.appendChild(common);

  const box = document.createElement('div');
  box.className = 'sp';
  box.appendChild(makeThumb(species.photo, species.sci));
  box.appendChild(names);

  const firstCell = document.createElement('td');
  firstCell.appendChild(box);
  row.appendChild(firstCell);

  // the other cells
  row.appendChild(makeCell(species.fam));
  row.appendChild(makeCell(species.loc));

  const statusCell = document.createElement('td');
  statusCell.appendChild(makePill(species.status));
  row.appendChild(statusCell);

  // delete button
  const deleteButton = document.createElement('button');
  deleteButton.className = 'btn ghost';
  deleteButton.textContent = 'Delete';
  deleteButton.onclick = function (event) {
    event.stopPropagation();   // do not also open the editor
    deleteSpecies(index);
  };
  const buttonCell = document.createElement('td');
  buttonCell.appendChild(deleteButton);
  row.appendChild(buttonCell);

  return row;
}


// Draw the table again, showing only the species that match the search box and status filter
function drawSpeciesTable() {
  const searchText = document.getElementById('search-box').value.toLowerCase();
  const chosenStatus = document.getElementById('status-filter').value;
  const list = getSpecies();
  const body = document.getElementById('species-body');
  body.innerHTML = '';
  let shown = 0;

  for (let i = 0; i < list.length; i++) {
    const species = list[i];
    const names = (species.sci + ' ' + species.com).toLowerCase();

    const nameMatches = names.indexOf(searchText) !== -1;
    let statusMatches = false;
    if (chosenStatus === '' || species.status === chosenStatus) {
      statusMatches = true;
    }

    if (nameMatches && statusMatches) {
      body.appendChild(makeSpeciesRow(species, i));
      shown = shown + 1;
    }
  }

  // show the "nothing found" message only when no row is visible
  document.getElementById('no-species').hidden = (shown > 0);
}


function deleteSpecies(index) {
  const sure = confirm('Delete this species record?');
  if (sure === false) {
    return;
  }
  const list = getSpecies();
  list.splice(index, 1);          // remove 1 item at this position
  writeStorage(SPECIES_KEY, list);
  showToast('Species deleted');
  drawSpeciesTable();
}


drawSpeciesTable();
