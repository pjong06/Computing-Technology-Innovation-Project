// pdf.js - builds a PDF file by hand (no library needed).
//
// How a PDF is made, in 4 steps (see makePdf at the bottom):
//   1. work out how wide each column is
//   2. lay out the table on pages (each page is a list of drawing commands)
//   3. add the footer ("Page 1 of 2") to every page
//   4. write everything into the PDF file format
//
// Page size is A4 landscape. "top" always means: distance down from the top of the page.

const PAGE_W = 842;     // page width
const PAGE_H = 595;     // page height
const MARGIN = 40;
const LINE_H = 11.5;    // height of one line of text
const PAD_X = 5;        // space inside a cell (left and right)
const PAD_Y = 4;        // space inside a cell (top and bottom)
const FONT_SIZE = 9;
const HEADER_H = 20;    // height of the green header row

// Width of every letter in Helvetica (per 1000), starting at the space character.
// We need this to know when a line of text is too wide for its column.
const HELV = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
  556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
  1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
  667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
  333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
  556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];


// =====================================================
// Measuring and cutting text
// =====================================================

// How wide (in PDF units) will this text be?
function textWidth(text, size, bold) {
  let total = 0;
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code >= 32 && code <= 126) {
      total = total + HELV[code - 32];
    } else {
      total = total + 556;   // unknown letters get an average width
    }
  }
  let width = total * size / 1000;
  if (bold) {
    width = width * 1.06;    // bold letters are a little wider
  }
  return width;
}

// If one single word is wider than the column, cut it into pieces.
// The pieces are added to "lines"; the last piece is returned.
function cutLongWord(word, maxWidth, size, bold, lines) {
  while (textWidth(word, size, bold) > maxWidth && word.length > 1) {
    let n = word.length - 1;
    while (n > 1 && textWidth(word.slice(0, n), size, bold) > maxWidth) {
      n = n - 1;
    }
    lines.push(word.slice(0, n));
    word = word.slice(n);
  }
  return word;
}

// Turn tabs, line breaks and repeated spaces into single spaces
function cleanSpaces(text) {
  let result = '';
  let lastWasSpace = false;
  for (let i = 0; i < text.length; i++) {
    const letter = text.charAt(i);
    if (letter === ' ' || letter === '\t' || letter === '\n' || letter === '\r') {
      if (lastWasSpace === false) {
        result = result + ' ';
      }
      lastWasSpace = true;
    } else {
      result = result + letter;
      lastWasSpace = false;
    }
  }
  return result.trim();
}

// Split text into a list of lines that each fit inside maxWidth
function wrapText(text, maxWidth, size, bold) {
  const lines = [];
  let cleaned = '';
  if (text !== null && text !== undefined) {
    cleaned = cleanSpaces(String(text));
  }
  const words = cleaned.split(' ');
  let line = '';

  for (let i = 0; i < words.length; i++) {
    let word = words[i];
    let attempt = word;
    if (line !== '') {
      attempt = line + ' ' + word;
    }

    if (textWidth(attempt, size, bold) <= maxWidth) {
      line = attempt;            // the word fits on this line
      continue;
    }
    if (line !== '') {
      lines.push(line);          // finish this line, start a new one
      line = '';
    }
    line = cutLongWord(word, maxWidth, size, bold, lines);
  }
  lines.push(line);
  return lines;
}


// =====================================================
// Preparing text and colours for the PDF
// =====================================================

// "#a01818" -> "0.627 0.094 0.094"   (PDF wants red green blue between 0 and 1)
function pdfColor(hex) {
  const parts = [];
  for (let i = 0; i < 3; i++) {
    const twoLetters = hex.substr(1 + i * 2, 2);
    const number = parseInt(twoLetters, 16) / 255;
    parts.push(number.toFixed(3));
  }
  return parts.join(' ');
}

// Text colour for each conservation status
function statusColor(value) {
  if (value === 'Endangered') {
    return '#a01818';
  }
  if (value === 'Vulnerable') {
    return '#a67c00';
  }
  if (value === 'Least Concern') {
    return '#2f4a3b';
  }
  return '#222222';
}

// The PDF fonts only understand simple letters, so we convert the text:
//   - fancy dashes and quotes become their Windows-1252 codes
//   - letters the font does not have become "?"
//   - the characters \ ( ) get a backslash in front (PDF rule)
function pdfText(text) {
  const fancy = { 8211: 150, 8212: 151, 8216: 145, 8217: 146, 8220: 147, 8221: 148, 8226: 149, 8230: 133 };
  let result = '';

  for (let i = 0; i < text.length; i++) {
    let code = text.charCodeAt(i);

    if (fancy[code]) {
      code = fancy[code];
    } else if (code === 9 || code === 10 || code === 13) {
      code = 32;                                   // tab / line break -> space
    } else if (code >= 32 && code <= 126) {
      // normal letter: keep it
    } else if (code >= 160 && code <= 255) {
      // letters like é: keep them
    } else {
      code = 63;                                   // 63 is "?"
    }

    let letter = String.fromCharCode(code);
    if (letter === '\\' || letter === '(' || letter === ')') {
      letter = '\\' + letter;
    }
    result = result + letter;
  }
  return result;
}


// =====================================================
// Drawing commands (each one adds a line to the page)
// =====================================================
// "page" is a list of text commands. y is measured down from the top, so we
// flip it (PAGE_H - top) because the PDF measures up from the bottom.

function drawText(page, x, top, str, size, font, color) {
  const bottom = PAGE_H - top - size * 0.8;
  page.push('BT /' + font + ' ' + size + ' Tf ' + pdfColor(color) + ' rg ' +
    x.toFixed(2) + ' ' + bottom.toFixed(2) + ' Td (' + pdfText(str) + ') Tj ET');
}

function drawRect(page, x, top, width, height, color) {
  const bottom = PAGE_H - top - height;
  page.push(pdfColor(color) + ' rg ' + x.toFixed(2) + ' ' + bottom.toFixed(2) + ' ' +
    width.toFixed(2) + ' ' + height.toFixed(2) + ' re f');
}

function drawLine(page, top, color) {
  const y = (PAGE_H - top).toFixed(2);
  page.push(pdfColor(color) + ' RG 0.5 w ' + MARGIN + ' ' + y + ' m ' + (PAGE_W - MARGIN) + ' ' + y + ' l S');
}


// =====================================================
// Step 1: column widths
// =====================================================
function getColumnWidths(report) {
  const usable = PAGE_W - 2 * MARGIN;

  let sum = 0;
  for (let c = 0; c < report.columns.length; c++) {
    sum = sum + report.columns[c].w;
  }

  const widths = [];
  for (let c = 0; c < report.columns.length; c++) {
    widths.push(usable * report.columns[c].w / sum);
  }
  return widths;
}


// =====================================================
// Step 2: lay out the pages
// =====================================================

// Draw the green row with the column names. Returns the new "top" position.
function drawTableHeader(page, top, report, colW) {
  drawRect(page, MARGIN, top, PAGE_W - 2 * MARGIN, HEADER_H, '#334f3f');
  let x = MARGIN;
  for (let c = 0; c < report.columns.length; c++) {
    drawText(page, x + PAD_X, top + 6, report.columns[c].label, FONT_SIZE, 'F2', '#ffffff');
    x = x + colW[c];
  }
  return top + HEADER_H;
}

// Start a new page. The first page also gets the big title.
// Returns { page: ..., top: ... }
function startPage(pages, report, generated, colW, isFirstPage) {
  const page = [];
  pages.push(page);
  let top = MARGIN;

  if (isFirstPage) {
    drawText(page, MARGIN, top, 'NIAH GROUND-TRUTH · CONSERVATION OFFICER REPORT', 8, 'F2', '#6f8577');
    top = top + 16;
    drawText(page, MARGIN, top, report.title, 20, 'F2', '#334f3f');
    top = top + 28;
    drawText(page, MARGIN, top, 'Generated ' + generated + ' · ' + report.summary, 9, 'F1', '#555555');
    top = top + 20;
  }

  top = drawTableHeader(page, top, report, colW);
  return { page: page, top: top };
}

// Cut the text of every cell in one row into lines. Returns a list of lists.
function wrapRow(report, rowNumber, colW) {
  const cells = [];
  for (let c = 0; c < report.columns.length; c++) {
    const maxWidth = colW[c] - 2 * PAD_X;
    cells.push(wrapText(report.rows[rowNumber][c], maxWidth, FONT_SIZE, false));
  }
  return cells;
}

// Draw one table row. Returns the new "top" position (below the row).
function drawRow(page, top, rowNumber, cells, rowHeight, report, colW) {
  // light grey background on every second row
  if (rowNumber % 2 === 1) {
    drawRect(page, MARGIN, top, PAGE_W - 2 * MARGIN, rowHeight, '#f3f6f4');
  }

  let x = MARGIN;
  for (let c = 0; c < report.columns.length; c++) {
    const column = report.columns[c];

    // choose the font: F1 normal, F2 bold, F3 italic
    let font = 'F1';
    if (column.pill) {
      font = 'F2';
    } else if (column.italic) {
      font = 'F3';
    }

    // choose the colour
    let color = '#222222';
    if (column.pill) {
      color = statusColor(report.rows[rowNumber][c]);
    }

    for (let line = 0; line < cells[c].length; line++) {
      drawText(page, x + PAD_X, top + PAD_Y + line * LINE_H, cells[c][line], FONT_SIZE, font, color);
    }
    x = x + colW[c];
  }

  const bottom = top + rowHeight;
  drawLine(page, bottom, '#e0e8e3');
  return bottom;
}

// Put all the rows on pages. Starts a new page when a row does not fit.
function layoutPages(report, generated, colW) {
  const pages = [];
  let start = startPage(pages, report, generated, colW, true);
  let page = start.page;
  let top = start.top;

  for (let r = 0; r < report.rows.length; r++) {
    const cells = wrapRow(report, r, colW);

    // the row is as tall as its tallest cell
    let mostLines = 1;
    for (let c = 0; c < cells.length; c++) {
      if (cells[c].length > mostLines) {
        mostLines = cells[c].length;
      }
    }
    const rowHeight = mostLines * LINE_H + 2 * PAD_Y;

    // not enough room left on this page? start a new one
    if (top + rowHeight > PAGE_H - MARGIN - 18) {
      start = startPage(pages, report, generated, colW, false);
      page = start.page;
      top = start.top;
    }

    top = drawRow(page, top, r, cells, rowHeight, report, colW);
  }
  return pages;
}


// =====================================================
// Step 3: footer on every page
// =====================================================
function addFooters(pages, report) {
  for (let p = 0; p < pages.length; p++) {
    const page = pages[p];
    drawText(page, MARGIN, PAGE_H - 28, 'Niah Ground-Truth · ' + report.title, 8, 'F1', '#6f8577');

    const label = 'Page ' + (p + 1) + ' of ' + pages.length;
    const x = PAGE_W - MARGIN - textWidth(label, 8, false);
    drawText(page, x, PAGE_H - 28, label, 8, 'F1', '#6f8577');
  }
}


// =====================================================
// Step 4: write the PDF file format
// =====================================================
// A PDF is a list of numbered "objects" followed by a table (xref) that says
// where each object starts. Object numbers used here:
//   1 = catalog, 2 = list of pages, 3/4/5 = the three fonts,
//   then for every page: one object for its drawing commands + one for the page itself.
function writePdfFile(pages) {
  let out = '%PDF-1.4\n';
  const offsets = [];   // where each object starts in the file

  // small helper that adds one numbered object to the file
  function addObject(number, body) {
    offsets[number] = out.length;
    out = out + number + ' 0 obj\n' + body + '\nendobj\n';
  }

  // the list of page objects
  const pageRefs = [];
  for (let i = 0; i < pages.length; i++) {
    pageRefs.push((7 + i * 2) + ' 0 R');
  }

  addObject(1, '<< /Type /Catalog /Pages 2 0 R >>');
  addObject(2, '<< /Type /Pages /Kids [' + pageRefs.join(' ') + '] /Count ' + pages.length + ' >>');
  addObject(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  addObject(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  addObject(5, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>');

  for (let i = 0; i < pages.length; i++) {
    const content = pages[i].join('\n');
    addObject(6 + i * 2, '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream');
    addObject(7 + i * 2, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PAGE_W + ' ' + PAGE_H + '] ' +
      '/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents ' + (6 + i * 2) + ' 0 R >>');
  }

  // the xref table
  const totalObjects = 6 + pages.length * 2;
  const xrefStart = out.length;
  out = out + 'xref\n0 ' + totalObjects + '\n0000000000 65535 f \n';
  for (let i = 1; i < totalObjects; i++) {
    out = out + ('0000000000' + offsets[i]).slice(-10) + ' 00000 n \n';
  }
  out = out + 'trailer\n<< /Size ' + totalObjects + ' /Root 1 0 R >>\nstartxref\n' + xrefStart + '\n%%EOF';

  // turn the text into bytes
  const bytes = new Uint8Array(out.length);
  for (let i = 0; i < out.length; i++) {
    bytes[i] = out.charCodeAt(i) & 255;
  }
  return bytes;
}


// =====================================================
// Put the 4 steps together
// =====================================================
function makePdf(report, generated) {
  const colW = getColumnWidths(report);                  // step 1
  const pages = layoutPages(report, generated, colW);    // step 2
  addFooters(pages, report);                             // step 3
  return writePdfFile(pages);                            // step 4
}
