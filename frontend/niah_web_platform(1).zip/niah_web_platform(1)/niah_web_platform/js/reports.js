// reports.js - the Reports & export page: build a report, show a preview, download CSV.
// (The PDF download is made by pdf.js.)
// Needs shared.js (loaded before this file).

// A "report" is a plain object that looks like this:
//   {
//     key:     'inventory',            which report it is
//     title:   'Species inventory',
//     summary: '4 species records',
//     note:    '',                     small message shown above the table
//     columns: [ { label: 'Status', w: 1.1, italic: false, pill: true, hide: false } ],
//     rows:    [ ['Rafflesia', 'Corpse flower', ...], ... ]   one list of texts per row
//   }

drawMenu('reports.html');

const STATUS_ORDER = ['Endangered', 'Vulnerable', 'Least Concern'];


// =====================================================
// Small helpers
// =====================================================

// "2026-09-14" -> "14 Sep 2026"
function prettyDate(dateText) {
  if (!dateText) {
    return '';
  }
  const parts = dateText.split('-');
  if (parts.length !== 3) {
    return dateText;
  }
  const day = Number(parts[2]);
  const monthName = MONTHS[Number(parts[1]) - 1];
  return day + ' ' + monthName + ' ' + parts[0];
}

function pluralize(count, word) {
  if (count === 1) {
    return count + ' ' + word;
  }
  return count + ' ' + word + 's';
}


// =====================================================
// Step 1: collect the saved data
// =====================================================

// Every species in the catalogue
function speciesList() {
  return getSpecies();
}

// Every observation (waiting, approved and rejected), with the review status as text
function observationList() {
  const all = getObservations();
  const list = [];
  for (let i = 0; i < all.length; i++) {
    const o = all[i];
    list.push({
      id: o.id, sci: o.sci, by: o.by, date: o.date,
      when: o.when, loc: o.loc, gps: o.gps, state: reviewText(o)
    });
  }
  return list;
}


// =====================================================
// Step 2: build the report the officer selected
// =====================================================

// "1 Sep 2026 to 12 Oct 2026"
function periodText(from, to) {
  let startText = 'start';
  if (from) {
    startText = prettyDate(from);
  }
  let endText = 'today';
  if (to) {
    endText = prettyDate(to);
  }
  return startText + ' to ' + endText;
}

// Is a date inside the date range? A record with no date is always included.
function dateInRange(date, from, to) {
  if (!date) {
    return true;
  }
  if (from && date < from) {
    return false;
  }
  if (to && date > to) {
    return false;
  }
  return true;
}

function buildInventoryReport(report, from, to) {
  report.title = 'Species inventory';
  report.note = 'The date range uses the date each species was first recorded.';
  report.columns = [
    { label: 'Scientific name', w: 1.4, italic: true },
    { label: 'Common name', w: 1.3 },
    { label: 'Family', w: 1.45 },
    { label: 'Status', w: 1.1, pill: true },
    { label: 'Location', w: 1.3 },
    { label: 'GPS (lat, lng)', w: 1.1 },
    { label: 'First recorded', w: 1.8 },
    { label: 'Last updated', w: 1.8 },
    { label: 'Description', w: 2.1, hide: true }   // hide = only in CSV / PDF, not in the preview
  ];

  if (from && to && from > to) {
    report.note = 'The start date is after the end date.';
  } else {
    const species = speciesList();
    for (let i = 0; i < species.length; i++) {
      const s = species[i];
      if (dateInRange(s.firstDate, from, to) === false) {
        continue;
      }
      let firstText = s.firstWhen;
      if (!firstText) {
        firstText = 'Not recorded';
      }
      let lastText = s.when;
      if (!lastText) {
        lastText = 'Not recorded';
      }
      report.rows.push([s.sci, s.com, s.fam, s.status, s.loc, s.gps, firstText, lastText, s.desc]);
    }
  }
  report.summary = pluralize(report.rows.length, 'species record') + ' · ' + periodText(from, to);
}

function buildStatusReport(report) {
  const species = speciesList();
  report.title = 'Conservation status summary';
  report.note = 'The status summary counts every species record, so the date range does not apply.';
  report.columns = [
    { label: 'Status', w: 1, pill: true },
    { label: 'Species', w: 0.7 },
    { label: 'Scientific names', w: 4 }
  ];

  // one row for each status, listing the species that have it
  for (let i = 0; i < STATUS_ORDER.length; i++) {
    const names = [];
    for (let j = 0; j < species.length; j++) {
      if (species[j].status === STATUS_ORDER[i]) {
        names.push(species[j].sci);
      }
    }
    report.rows.push([STATUS_ORDER[i], String(names.length), names.join('; ')]);
  }
  report.rows.push(['Total', String(species.length), '']);
  report.summary = pluralize(species.length, 'species record');
}

// Used to sort observations: botanist name first, then newest date first
function compareObservations(a, b) {
  if (a.by < b.by) {
    return -1;
  }
  if (a.by > b.by) {
    return 1;
  }
  if (a.date < b.date) {
    return 1;
  }
  if (a.date > b.date) {
    return -1;
  }
  return 0;
}

function buildBotanistReport(report, from, to) {
  report.title = 'Observations by botanist';
  report.columns = [
    { label: 'Botanist', w: 1.1 },
    { label: 'Record', w: 1.1 },
    { label: 'Species', w: 1.5, italic: true },
    { label: 'Recorded', w: 1.4 },
    { label: 'Location', w: 1.3 },
    { label: 'GPS (lat, lng)', w: 1.2 },
    { label: 'Review status', w: 0.9 }
  ];

  const period = periodText(from, to);

  if (from && to && from > to) {
    report.note = 'The start date is after the end date.';
  } else {
    // keep only the observations inside the date range
    const all = observationList();
    const inRange = [];
    for (let i = 0; i < all.length; i++) {
      const o = all[i];
      if (from && o.date < from) {
        continue;
      }
      if (to && o.date > to) {
        continue;
      }
      inRange.push(o);
    }

    inRange.sort(compareObservations);
    for (let i = 0; i < inRange.length; i++) {
      const o = inRange[i];
      report.rows.push([o.by, o.id, o.sci, o.when, o.loc, o.gps, o.state]);
    }
  }
  report.summary = pluralize(report.rows.length, 'observation') + ' · ' + period;
}

function buildReport() {
  const key = document.getElementById('report-type').value;
  const from = document.getElementById('report-from').value;
  const to = document.getElementById('report-to').value;

  const report = { key: key, title: '', summary: '', note: '', columns: [], rows: [] };

  if (key === 'inventory') {
    buildInventoryReport(report, from, to);
  } else if (key === 'status') {
    buildStatusReport(report);
  } else {
    buildBotanistReport(report, from, to);
  }
  return report;
}


// =====================================================
// Step 3: show the preview on the page
// =====================================================

// The number cards at the top of the page
function showNumberCards() {
  const species = speciesList();
  let endangered = 0;
  for (let i = 0; i < species.length; i++) {
    if (species[i].status === 'Endangered') {
      endangered = endangered + 1;
    }
  }
  document.getElementById('stat-species').textContent = species.length;
  document.getElementById('stat-endangered').textContent = endangered;
  let pending = 0;
  const observations = getObservations();
  for (let i = 0; i < observations.length; i++) {
    if (observations[i].state === 'Pending') {
      pending = pending + 1;
    }
  }
  document.getElementById('stat-pending').textContent = pending;
}

// Make the <td> for one cell of the preview table
function makeCell(column, value) {
  const td = document.createElement('td');

  if (column.pill && STATUS_ORDER.indexOf(value) !== -1) {
    // a coloured pill for the conservation status
    const pill = document.createElement('span');
    pill.textContent = value;
    if (value === 'Endangered') {
      pill.className = 'pill e';
    } else if (value === 'Vulnerable') {
      pill.className = 'pill w';
    } else {
      pill.className = 'pill';
    }
    td.appendChild(pill);
  } else if (column.italic) {
    // scientific names are written in italics
    const italic = document.createElement('i');
    italic.className = 'sci';
    italic.textContent = value;
    td.appendChild(italic);
  } else {
    td.textContent = value;
  }
  return td;
}

function renderReport() {
  showNumberCards();

  const report = buildReport();
  document.getElementById('report-note').textContent = report.note;

  const head = document.getElementById('report-head');
  const body = document.getElementById('report-body');
  head.innerHTML = '';
  body.innerHTML = '';

  // the header row
  const headRow = document.createElement('tr');
  for (let c = 0; c < report.columns.length; c++) {
    if (report.columns[c].hide) {
      continue;
    }
    const th = document.createElement('th');
    th.textContent = report.columns[c].label;
    headRow.appendChild(th);
  }
  head.appendChild(headRow);

  // one table row for every report row
  for (let r = 0; r < report.rows.length; r++) {
    const tr = document.createElement('tr');
    for (let c = 0; c < report.columns.length; c++) {
      if (report.columns[c].hide) {
        continue;
      }
      tr.appendChild(makeCell(report.columns[c], report.rows[r][c]));
    }
    body.appendChild(tr);
  }

  document.getElementById('report-empty').hidden = (report.rows.length > 0);
}


// =====================================================
// Downloading files
// =====================================================

// Example: niah-species-inventory-2026-10-12.csv
function fileName(report, extension) {
  const today = new Date();
  const stamp = isoDate(today);
  const names = {
    inventory: 'species-inventory',
    status: 'conservation-status-summary',
    botanist: 'observations-by-botanist'
  };
  return 'niah-' + names[report.key] + '-' + stamp + '.' + extension;
}

// Make the browser download a file (works for CSV and PDF)
function downloadFile(name, blob) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(function () {
    URL.revokeObjectURL(url);
  }, 1000);
}


// =====================================================
// CSV
// =====================================================
function isDigit(character) {
  return character >= '0' && character <= '9';
}

// Put one value inside quotes so commas and line breaks cannot break the CSV
function csvCell(value) {
  let text = '';
  if (value !== null && value !== undefined) {
    text = String(value);
  }

  // Stop Excel from treating typed-in text as a formula (for example "=1+1")
  const first = text.charAt(0);
  if (first === '=' || first === '+' || first === '@') {
    text = "'" + text;
  }
  if (first === '-' && isDigit(text.charAt(1)) === false) {
    text = "'" + text;
  }

  // a quote inside the text is written as two quotes
  text = text.split('"').join('""');
  return '"' + text + '"';
}

function exportCsv() {
  const report = buildReport();
  if (report.rows.length === 0) {
    showToast('Nothing to export for this selection');
    return;
  }

  const lines = [];

  // first line: the column names
  const labels = [];
  for (let c = 0; c < report.columns.length; c++) {
    labels.push(csvCell(report.columns[c].label));
  }
  lines.push(labels.join(','));

  // one line for each row
  for (let r = 0; r < report.rows.length; r++) {
    const cells = [];
    for (let c = 0; c < report.columns.length; c++) {
      cells.push(csvCell(report.rows[r][c]));
    }
    lines.push(cells.join(','));
  }

  // the special character at the start lets Excel read the file as UTF-8
  const text = '\uFEFF' + lines.join('\r\n') + '\r\n';
  const blob = new Blob([text], { type: 'text/csv;charset=utf-8' });
  downloadFile(fileName(report, 'csv'), blob);
  showToast('CSV downloaded');
}


// =====================================================
// PDF button (the work is done by makePdf in pdf.js)
// =====================================================
function exportPdf() {
  const report = buildReport();
  if (report.rows.length === 0) {
    showToast('Nothing to export for this selection');
    return;
  }

  const now = new Date();
  const generated = whenText(now);

  const bytes = makePdf(report, generated);
  downloadFile(fileName(report, 'pdf'), new Blob([bytes], { type: 'application/pdf' }));
  showToast('PDF downloaded');
}


// The date range ends today by default, so a record saved today is included
document.getElementById('report-to').value = isoDate(new Date());

// Show the report as soon as the page opens
renderReport();
