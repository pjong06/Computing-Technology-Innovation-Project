// queue.js - the Observation approval queue page.
// Needs shared.js (loaded before this file).

drawMenu('queue.html');

let selectedId = null;   // the id of the observation selected in the list (for example "NP-2026-0417")


// ---------- Helpers ----------

// Only the observations that are still waiting for a decision
function getPending() {
  const all = getObservations();
  const pending = [];
  for (let i = 0; i < all.length; i++) {
    if (all[i].state === 'Pending') {
      pending.push(all[i]);
    }
  }
  return pending;
}

// Find one observation by its id (null if not found)
function findObservation(list, id) {
  for (let i = 0; i < list.length; i++) {
    if (list[i].id === id) {
      return list[i];
    }
  }
  return null;
}

// Find a species by scientific name (null if not found)
function findSpecies(list, scientificName) {
  for (let i = 0; i < list.length; i++) {
    if (list[i].sci === scientificName) {
      return list[i];
    }
  }
  return null;
}

// The photo of an observation. Old saved observations may have no photo,
// so we use the photo of the same species from the catalogue, or the blank picture.
function observationPhoto(observation) {
  if (observation.photo) {
    return observation.photo;
  }
  const species = findSpecies(getSpecies(), observation.sci);
  if (species !== null) {
    return species.photo;
  }
  return PICTURE_BLANK;
}

// <p><b>Title</b><br>text</p>
function addInfo(parent, title, text) {
  const paragraph = document.createElement('p');
  const bold = document.createElement('b');
  bold.textContent = title;
  paragraph.appendChild(bold);
  paragraph.appendChild(document.createElement('br'));
  paragraph.appendChild(document.createTextNode(text));
  parent.appendChild(paragraph);
}


// ---------- Drawing the page ----------

// One small card in the list on the left
function makeListCard(observation) {
  const card = document.createElement('div');
  card.className = 'q';
  if (observation.id === selectedId) {
    card.classList.add('on');
  }
  card.onclick = function () {
    selectedId = observation.id;
    drawQueue();
  };

  const bold = document.createElement('b');
  const name = document.createElement('i');
  name.className = 'sci';
  name.textContent = observation.sci;
  bold.appendChild(name);

  const small = document.createElement('span');
  small.className = 'muted';
  small.textContent = observation.by + ' · ' + observation.when;

  const text = document.createElement('div');
  text.appendChild(bold);
  text.appendChild(small);

  // small photo on the left, names on the right
  const row = document.createElement('div');
  row.className = 'sp';
  row.appendChild(makeThumb(observationPhoto(observation), observation.sci));
  row.appendChild(text);
  card.appendChild(row);

  return card;
}

// The big card on the right, with the Approve and Reject buttons
function makeDetailCard(observation) {
  const card = document.createElement('div');
  card.className = 'card detail';

  const title = document.createElement('h3');
  title.style.marginTop = '0';
  const name = document.createElement('i');
  name.className = 'sci';
  name.textContent = observation.sci;
  title.appendChild(name);
  card.appendChild(title);

  const record = document.createElement('p');
  record.className = 'muted';
  record.textContent = 'Record ' + observation.id;
  card.appendChild(record);

  // the photo the botanist took, so the officer can check the species
  const picture = document.createElement('img');
  picture.className = 'obs-photo';
  picture.src = observationPhoto(observation);
  picture.alt = 'Photo of ' + observation.sci;
  card.appendChild(picture);

  addInfo(card, 'Location', observation.loc + ' · ' + prettyGps(observation.gps));
  addInfo(card, 'Recorded by', observation.by + ', ' + observation.when);
  addInfo(card, 'Notes', observation.notes);

  const approveButton = document.createElement('button');
  approveButton.className = 'btn';
  approveButton.textContent = 'Approve';
  approveButton.onclick = function () {
    reviewObservation(observation.id, 'Approved');
  };

  const rejectButton = document.createElement('button');
  rejectButton.className = 'btn red';
  rejectButton.textContent = 'Reject';
  rejectButton.onclick = function () {
    reviewObservation(observation.id, 'Rejected');
  };

  const buttons = document.createElement('div');
  buttons.className = 'acts';
  buttons.appendChild(approveButton);
  buttons.appendChild(rejectButton);
  card.appendChild(buttons);

  return card;
}

function drawQueue() {
  const pending = getPending();

  // nothing left: show the "All caught up" box
  if (pending.length === 0) {
    document.getElementById('queue-area').hidden = true;
    document.getElementById('queue-empty').hidden = false;
    document.getElementById('queue-count').textContent = '0 field observations waiting for review.';
    return;
  }
  document.getElementById('queue-area').hidden = false;
  document.getElementById('queue-empty').hidden = true;

  // the sentence at the top
  let word = 'observations';
  if (pending.length === 1) {
    word = 'observation';
  }
  document.getElementById('queue-count').textContent =
    pending.length + ' field ' + word + ' waiting for review.';

  // if nothing is selected (or the selected one was just reviewed), select the first
  let selected = findObservation(pending, selectedId);
  if (selected === null) {
    selected = pending[0];
    selectedId = selected.id;
  }

  // the list on the left
  const listBox = document.getElementById('queue-list');
  listBox.innerHTML = '';
  for (let i = 0; i < pending.length; i++) {
    listBox.appendChild(makeListCard(pending[i]));
  }

  // the details on the right
  const detailBox = document.getElementById('queue-detail');
  detailBox.innerHTML = '';
  detailBox.appendChild(makeDetailCard(selected));
}


// ---------- Approve / Reject ----------
// result is 'Approved' or 'Rejected'
//
// APPROVED: the observation is saved as Approved, and the species in the catalogue gets
//           the observation's location and GPS (so the map shows it).
// REJECTED: the officer must type a reason. The observation is saved as Rejected with the
//           reason. The catalogue and the map do not change.
// Either way it leaves the queue, and the Reports page shows its new status.
function reviewObservation(id, result) {
  const observations = getObservations();
  const observation = findObservation(observations, id);

  let reason = '';
  if (result === 'Rejected') {
    reason = prompt('Why are you rejecting this observation? (saved with the record)');
    if (reason === null) {
      return;                        // Cancel was pressed: do nothing
    }
    reason = reason.trim();
    if (reason === '') {
      showToast('Please type a reason');
      return;
    }
  }

  observation.state = result;
  observation.reason = reason;
  writeStorage(OBSERVATIONS_KEY, observations);

  if (result === 'Approved') {
    const speciesList = getSpecies();
    const species = findSpecies(speciesList, observation.sci);
    if (species !== null) {
      species.loc = observation.loc;
      species.gps = observation.gps;
      writeStorage(SPECIES_KEY, speciesList);
    }
  }

  showToast('Observation ' + result.toLowerCase());
  drawQueue();
}


// ---------- Reset ----------
// Put the queue back to the 3 starting observations (all waiting for review).
// Useful for testing and demos.
function resetQueue() {
  const sure = confirm('Reset the queue? All observations go back to "waiting for review".');
  if (sure === false) {
    return;
  }
  writeStorage(OBSERVATIONS_KEY, makeStartingObservations());
  selectedId = null;
  showToast('Queue reset');
  drawQueue();
}


drawQueue();
