// shared.js - loaded by EVERY page.
// It holds: the saved data, the left menu, the pop-up message and a few small helpers.
//
// Each page is its own .html file. When you move from one page to another the browser
// forgets everything, so the data is saved in "localStorage" (the browser's small notebook).
// Every page reads the same notebook, so they all see the same species, observations and users.

// ---------- Names of the notebook pages (keys) ----------
const SPECIES_KEY = 'niah_species';
const OBSERVATIONS_KEY = 'niah_observations';
const USERS_KEY = 'niah_users';
const EDIT_KEY = 'niah_editing';    // which species the editor should open (-1 = a new one)
const TOAST_KEY = 'niah_toast';     // a message to show on the next page


// =====================================================
// Pictures (small drawings used when a species has no photo)
// =====================================================
function svgPicture(svg) {
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

const PICTURE_RAFFLESIA = svgPicture('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56"><rect width="56" height="56" fill="#3b4a2a"/><circle cx="28" cy="13" r="10" fill="#e0623a"/><circle cx="28" cy="13" r="10" fill="#e0623a" transform="rotate(72 28 28)"/><circle cx="28" cy="13" r="10" fill="#e0623a" transform="rotate(144 28 28)"/><circle cx="28" cy="13" r="10" fill="#e0623a" transform="rotate(216 28 28)"/><circle cx="28" cy="13" r="10" fill="#e0623a" transform="rotate(288 28 28)"/><circle cx="28" cy="28" r="11" fill="#f0a070"/><circle cx="28" cy="28" r="6" fill="#7a2410"/></svg>');
const PICTURE_SHOREA = svgPicture('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56"><rect width="56" height="56" fill="#cfe3c4"/><rect x="25" y="26" width="6" height="28" fill="#6b4a2f"/><circle cx="28" cy="20" r="14" fill="#4f8a4f"/><circle cx="18" cy="26" r="9" fill="#5b9a58"/><circle cx="38" cy="26" r="9" fill="#5b9a58"/></svg>');
const PICTURE_NEPENTHES = svgPicture('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56"><rect width="56" height="56" fill="#1f3a2a"/><path d="M28 6c-9 0-12 10-12 20 0 9 5 16 12 16s12-7 12-16C40 16 37 6 28 6z" fill="#e8962e"/><ellipse cx="28" cy="8" rx="9" ry="3.5" fill="#a85d12"/><path d="M28 42v10" stroke="#7fae8f" stroke-width="3"/></svg>');
const PICTURE_DIPTEROCARPUS = svgPicture('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56"><rect width="56" height="56" fill="#6aa05a"/><path d="M10 46C10 22 26 8 46 10 46 32 34 46 10 46z" fill="#2f6b3a"/><path d="M12 44L38 18" stroke="#a9d49a" stroke-width="2"/></svg>');
const PICTURE_BLANK = svgPicture('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56"><rect width="56" height="56" fill="#6aa05a"/><path d="M10 46C10 22 26 8 46 10 46 32 34 46 10 46z" fill="#2f6b3a"/><path d="M12 44L38 18" stroke="#a9d49a" stroke-width="2"/></svg>');


// =====================================================
// Saving and loading
// =====================================================

// Read a saved value. Returns null if nothing was saved yet.
function readStorage(key) {
  const text = localStorage.getItem(key);
  if (text === null) {
    return null;
  }
  return JSON.parse(text);
}

// Save a value. Returns true if it worked, false if the browser is full
// (a very big photo can fill it).
function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    return false;
  }
}


// =====================================================
// Dates and times
// =====================================================
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// 5 -> "05"
function twoDigits(number) {
  return ('0' + number).slice(-2);
}

// A Date -> "2026-09-14"   (used for sorting and for the date range)
function isoDate(d) {
  return d.getFullYear() + '-' + twoDigits(d.getMonth() + 1) + '-' + twoDigits(d.getDate());
}

// A Date -> "14 Sep 2026, 3:42 PM"   (the date AND the time, shown to people)
function whenText(d) {
  let hour = d.getHours();
  let ampm = 'AM';
  if (hour >= 12) {
    ampm = 'PM';
  }
  hour = hour % 12;
  if (hour === 0) {
    hour = 12;
  }
  return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear() + ', ' +
    hour + ':' + twoDigits(d.getMinutes()) + ' ' + ampm;
}


// =====================================================
// The starting data (used the first time, before anything is saved)
// =====================================================
// date / when       = when the record was last saved (changes on every edit)
// firstDate / firstWhen = when the species was first recorded (never changes)
// (the times below are stand-ins until the mobile app syncs real ones)
function makeStartingSpecies() {
  return [
    {
      sci: 'Rafflesia tuan-mudae', com: 'Corpse flower', fam: 'Rafflesiaceae',
      status: 'Endangered', loc: 'West trail junction', gps: '3.2247, 113.7631',
      desc: 'A parasitic flowering plant that produces the largest individual flower in the world. It has no visible leaves, stems or roots.',
      photo: PICTURE_RAFFLESIA,
      date: '2026-09-14', when: '14 Sep 2026, 3:42 PM',
      firstDate: '2026-09-14', firstWhen: '14 Sep 2026, 3:42 PM'
    },
    {
      sci: 'Shorea platyclados', com: 'Meranti bukit', fam: 'Dipterocarpaceae',
      status: 'Vulnerable', loc: '2.3km trail, Niah', gps: '3.2201, 113.7702',
      desc: 'A large lowland dipterocarp tree found along the Niah trail.',
      photo: PICTURE_SHOREA,
      date: '2026-09-10', when: '10 Sep 2026, 10:20 AM',
      firstDate: '2026-09-10', firstWhen: '10 Sep 2026, 10:20 AM'
    },
    {
      sci: 'Nepenthes ampullaria', com: 'Pitcher plant', fam: 'Nepenthaceae',
      status: 'Least Concern', loc: 'Cave entrance area', gps: '3.2189, 113.7745',
      desc: 'A carnivorous pitcher plant with rounded, clustered pitchers.',
      photo: PICTURE_NEPENTHES,
      date: '2026-09-14', when: '14 Sep 2026, 11:10 AM',
      firstDate: '2026-09-14', firstWhen: '14 Sep 2026, 11:10 AM'
    },
    {
      sci: 'Dipterocarpus caudatus', com: 'Keruing', fam: 'Dipterocarpaceae',
      status: 'Endangered', loc: 'Keruing', gps: '3.2268, 113.7598',
      desc: 'A tall emergent tree valued for timber, now under pressure.',
      photo: PICTURE_DIPTEROCARPUS,
      date: '2026-09-12', when: '12 Sep 2026, 9:05 AM',
      firstDate: '2026-09-12', firstWhen: '12 Sep 2026, 9:05 AM'
    }
  ];
}

// photo = the picture the botanist took in the field (here: a drawing, as a stand-in)
// state is 'Pending', 'Approved' or 'Rejected' (reason is only used when Rejected)
function makeStartingObservations() {
  return [
    {
      id: 'NP-2026-0417', sci: 'Rafflesia tuan-mudae', by: 'Brendan Noel',
      date: '2026-09-14', when: '14 Sep 2026, 3:42 PM',
      loc: 'West trail junction', gps: '3.2247, 113.7631',
      notes: 'Single bloom, about 60 cm wide. Photo attached.',
      photo: PICTURE_RAFFLESIA,
      state: 'Pending', reason: ''
    },
    {
      id: 'NP-2026-0418', sci: 'Nepenthes ampullaria', by: 'Brendan Noel',
      date: '2026-09-14', when: '14 Sep 2026, 11:10 AM',
      loc: 'Cave entrance area', gps: '3.2189, 113.7745',
      notes: 'Cluster of 6 pitchers near the path.',
      photo: PICTURE_NEPENTHES,
      state: 'Pending', reason: ''
    },
    {
      id: 'NP-2026-0412', sci: 'Dipterocarpus caudatus', by: 'Aina Rahman',
      date: '2026-09-12', when: '12 Sep 2026, 9:05 AM',
      loc: 'Keruing', gps: '3.2268, 113.7598',
      notes: 'Height estimated at 38 m. Bark sample not taken.',
      photo: PICTURE_DIPTEROCARPUS,
      state: 'Pending', reason: ''
    }
  ];
}

function makeStartingUsers() {
  return [
    { name: 'Brendan Noel', email: 'brendan@sfc.example', role: 'Botanist', active: true },
    { name: 'Aina Rahman', email: 'aina@sfc.example', role: 'Botanist', active: true },
    { name: 'Daniel Ling', email: 'daniel@sfc.example', role: 'Conservation Officer', active: true },
    { name: 'Mei Tan', email: 'mei@sfc.example', role: 'Administrator', active: false }
  ];
}


// Find a species in a list by its scientific name (null if not found)
function findByScientificName(list, scientificName) {
  for (let i = 0; i < list.length; i++) {
    if (list[i].sci === scientificName) {
      return list[i];
    }
  }
  return null;
}

// =====================================================
// Get the saved lists (they are created on the first visit)
// =====================================================
function getSpecies() {
  let list = readStorage(SPECIES_KEY);
  if (list === null) {
    list = makeStartingSpecies();
    writeStorage(SPECIES_KEY, list);
  }
  // Species saved by an older version have no dates. Fill them in:
  //   - a sample species gets its sample date and time
  //   - any other species gets empty dates (the report shows "Not recorded")
  let changed = false;
  const starting = makeStartingSpecies();
  for (let i = 0; i < list.length; i++) {
    if (list[i].when === undefined || list[i].firstWhen === undefined) {
      const sample = findByScientificName(starting, list[i].sci);
      if (list[i].when === undefined || list[i].when === '') {
        list[i].date = '';
        list[i].when = '';
        if (sample !== null) {
          list[i].date = sample.date;
          list[i].when = sample.when;
        }
      }
      list[i].firstDate = list[i].date;   // first recorded: the oldest date we know
      list[i].firstWhen = list[i].when;
      if (sample !== null) {
        list[i].firstDate = sample.firstDate;
        list[i].firstWhen = sample.firstWhen;
      }
      changed = true;
    }
  }
  if (changed) {
    writeStorage(SPECIES_KEY, list);
  }
  return list;
}

function getObservations() {
  let list = readStorage(OBSERVATIONS_KEY);
  if (list === null) {
    list = makeStartingObservations();
    writeStorage(OBSERVATIONS_KEY, list);
  }
  return list;
}

function getUsers() {
  let list = readStorage(USERS_KEY);
  if (list === null) {
    list = makeStartingUsers();
    writeStorage(USERS_KEY, list);
  }
  return list;
}


// =====================================================
// The left menu
// =====================================================
const MENU = [
  { file: 'species.html', label: 'Species catalogue' },
  { file: 'editor.html', label: 'Species record editor' },
  { file: 'queue.html', label: 'Observation approval queue' },
  { file: 'map.html', label: 'Distribution map' },
  { file: 'reports.html', label: 'Reports & export' },
  { file: 'users.html', label: 'User & role admin' }
];

// Fill the <nav id="menu"> of the page. activeFile is the page we are on.
function drawMenu(activeFile) {
  const nav = document.getElementById('menu');

  const brand = document.createElement('div');
  brand.className = 'brand';
  brand.textContent = 'Niah Ground-Truth';
  nav.appendChild(brand);

  const sub = document.createElement('div');
  sub.className = 'sub';
  sub.textContent = 'Conservation Officer · Web';
  nav.appendChild(sub);

  for (let i = 0; i < MENU.length; i++) {
    const link = document.createElement('a');
    link.href = MENU[i].file;
    link.textContent = MENU[i].label;
    if (MENU[i].file === activeFile) {
      link.className = 'on';
    }
    nav.appendChild(link);
  }

  const who = document.createElement('div');
  who.className = 'who';
  who.textContent = 'Signed in as officer';
  nav.appendChild(who);
}


// =====================================================
// Small pop-up message
// =====================================================
function hideToast() {
  document.getElementById('toast').classList.remove('on');
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('on');
  setTimeout(hideToast, 2000);   // hide it again after 2 seconds
}

// Use this before you jump to another page: the next page will show the message.
function rememberToast(message) {
  writeStorage(TOAST_KEY, message);
}

function showRememberedToast() {
  const message = readStorage(TOAST_KEY);
  if (message !== null) {
    localStorage.removeItem(TOAST_KEY);
    showToast(message);
  }
}


// =====================================================
// Helpers used by several pages
// =====================================================

// Open the editor page. index = position of the species in the list, or -1 for a new one.
function openEditorFor(index) {
  writeStorage(EDIT_KEY, index);
  location.href = 'editor.html';
}

// Which colour of pill should a conservation status get?
function statusClass(status) {
  if (status === 'Endangered') {
    return 'pill e';
  }
  if (status === 'Vulnerable') {
    return 'pill w';
  }
  return 'pill';
}

// Turn the text "3.2247, 113.7631" into the list [3.2247, 113.7631]
// Returns null if the text is not a valid GPS location.
function readGps(text) {
  if (!text) {
    return null;
  }
  const parts = text.split(',');
  if (parts.length !== 2) {
    return null;
  }
  const lat = parseFloat(parts[0]);
  const lng = parseFloat(parts[1]);
  if (isNaN(lat) || isNaN(lng)) {
    return null;
  }
  return [lat, lng];
}

// "3.2247, 113.7631" -> "3.2247° N, 113.7631° E"   (unchanged if it is not valid)
function prettyGps(text) {
  const gps = readGps(text);
  if (gps === null) {
    return text;
  }
  let northSouth = 'N';
  if (gps[0] < 0) {
    northSouth = 'S';
  }
  let eastWest = 'E';
  if (gps[1] < 0) {
    eastWest = 'W';
  }
  return Math.abs(gps[0]).toFixed(4) + '° ' + northSouth + ', ' + Math.abs(gps[1]).toFixed(4) + '° ' + eastWest;
}

// The text shown in the "Review status" column: Pending, Approved or "Rejected: reason"
function reviewText(observation) {
  if (observation.state === 'Rejected') {
    return 'Rejected: ' + observation.reason;
  }
  return observation.state;
}

// Make a little photo box: <span class="thumbbox"><img></span>
function makeThumb(photo, altText) {
  const box = document.createElement('span');
  box.className = 'thumbbox';
  const img = document.createElement('img');
  img.src = photo;
  img.alt = altText;
  box.appendChild(img);
  return box;
}

// Make a coloured status pill: <span class="pill e">Endangered</span>
function makePill(status) {
  const pill = document.createElement('span');
  pill.className = statusClass(status);
  pill.textContent = status;
  return pill;
}

// Make <td>text</td>
function makeCell(text) {
  const td = document.createElement('td');
  td.textContent = text;
  return td;
}

// Once the page has loaded, show a message that the previous page left for us
showRememberedToast();
