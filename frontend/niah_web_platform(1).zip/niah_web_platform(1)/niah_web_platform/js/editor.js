// editor.js - the Species record editor page (add a new species or edit an existing one).
// Needs shared.js (loaded before this file).

drawMenu('editor.html');

let editIndex = -1;           // position of the species being edited (-1 = adding a NEW species)
let photo = PICTURE_BLANK;    // the photo for this species
let firstDate = '';           // when this species was first recorded (kept when editing)
let firstWhen = '';


// Show the photo in the preview box
function showPhoto() {
  const preview = document.getElementById('photo-preview');
  preview.innerHTML = '';
  preview.appendChild(makeThumb(photo, 'Species photo'));
}

// Fill the form. Called once, when the page opens.
function startEditor() {
  // which species did the other page ask us to open?
  let wanted = readStorage(EDIT_KEY);
  if (wanted === null) {
    wanted = -1;
  }
  writeStorage(EDIT_KEY, -1);   // forget it, so opening this page from the menu starts blank

  const list = getSpecies();
  if (wanted >= 0 && wanted < list.length) {
    // EDIT an existing species: fill the boxes with its data
    editIndex = wanted;
    const species = list[wanted];
    document.getElementById('editor-title').innerHTML = 'Edit <span>species record</span>';
    document.getElementById('f-sci').value = species.sci;
    document.getElementById('f-com').value = species.com;
    document.getElementById('f-fam').value = species.fam;
    document.getElementById('f-status').value = species.status;
    document.getElementById('f-loc').value = species.loc;
    document.getElementById('f-gps').value = species.gps;
    document.getElementById('f-desc').value = species.desc;
    photo = species.photo;
    firstDate = species.firstDate;     // keep the original date
    firstWhen = species.firstWhen;
  } else {
    // ADD a new species: the boxes stay empty
    editIndex = -1;
    document.getElementById('editor-title').innerHTML = 'Add <span>species record</span>';
    document.getElementById('f-status').value = 'Least Concern';
    photo = PICTURE_BLANK;
    firstDate = '';                    // filled in when it is saved
    firstWhen = '';
  }
  showPhoto();
}


// The file reader that turns the chosen photo into text we can save
let reader = null;

function photoIsRead() {
  photo = reader.result;
  showPhoto();
}

function previewPhoto(input) {
  const file = input.files[0];
  if (!file) {
    return;                         // the user cancelled
  }
  reader = new FileReader();
  reader.onload = photoIsRead;      // run photoIsRead when the file has been read
  reader.readAsDataURL(file);
}


function saveSpecies() {
  const sci = document.getElementById('f-sci').value.trim();
  if (sci === '') {
    showToast('Enter a scientific name');
    return;
  }

  const now = new Date();
  const species = {
    sci: sci,
    com: document.getElementById('f-com').value.trim(),
    fam: document.getElementById('f-fam').value.trim(),
    status: document.getElementById('f-status').value,
    loc: document.getElementById('f-loc').value.trim(),
    gps: document.getElementById('f-gps').value.trim(),
    desc: document.getElementById('f-desc').value.trim(),
    photo: photo,
    date: isoDate(now),      // last updated: now
    when: whenText(now),
    firstDate: firstDate,    // first recorded: kept from before, or now for a new species
    firstWhen: firstWhen
  };
  if (editIndex === -1) {
    species.firstDate = isoDate(now);
    species.firstWhen = whenText(now);
  }

  const list = getSpecies();
  if (editIndex === -1) {
    list.push(species);              // add at the end
  } else {
    list[editIndex] = species;       // replace the old one
  }

  const worked = writeStorage(SPECIES_KEY, list);
  if (worked === false) {
    showToast('Could not save. The photo may be too big.');
    return;
  }

  rememberToast('Species saved');    // the catalogue page will show this message
  location.href = 'species.html';
}


startEditor();
