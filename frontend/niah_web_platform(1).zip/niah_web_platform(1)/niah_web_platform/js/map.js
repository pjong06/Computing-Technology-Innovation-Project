// map.js - the Distribution map page (uses the Leaflet library loaded in map.html).
// Needs shared.js (loaded before this file).

drawMenu('map.html');

let map = null;           // the Leaflet map
let markerLayer = null;   // a group that holds all the coloured dots


// ---------- Create the map ----------
function createMap() {
  // centre of the map, then the zoom level
  map = L.map('map-box').setView([3.2247, 113.7631], 14);

  // All three map styles come from Esri, which does not need an API key
  const esri = 'https://server.arcgisonline.com/ArcGIS/rest/services/';

  const imagery = L.tileLayer(esri + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: 'Tiles &copy; Esri'
  });
  // satellite photos have no writing, so we lay town and place names on top
  const placeNames = L.tileLayer(esri + 'Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: 'Labels &copy; Esri'
  });
  const satellite = L.layerGroup([imagery, placeNames]);

  const street = L.tileLayer(esri + 'World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: 'Tiles &copy; Esri'
  });
  const topo = L.tileLayer(esri + 'World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: 'Tiles &copy; Esri'
  });

  satellite.addTo(map);   // the style shown first
  L.control.layers({ 'Satellite': satellite, 'Street': street, 'Topographic': topo }).addTo(map);
  markerLayer = L.layerGroup().addTo(map);
}


// ---------- Marker helpers ----------
function markerColor(status) {
  if (status === 'Endangered') {
    return '#c0392b';   // red
  }
  if (status === 'Vulnerable') {
    return '#e0a800';   // yellow
  }
  return '#3d8b4f';     // green
}

// Build the small box that opens when you click a dot
function makePopup(species, index) {
  const box = document.createElement('div');

  const title = document.createElement('b');
  title.textContent = species.sci;
  box.appendChild(title);

  const info = document.createElement('div');
  info.textContent = species.com + ' · ' + species.status;
  box.appendChild(info);

  const place = document.createElement('div');
  place.textContent = species.loc + ' (' + species.gps + ')';
  box.appendChild(place);

  const button = document.createElement('button');
  button.textContent = 'Edit record';
  button.onclick = function () {
    openEditorFor(index);
  };
  box.appendChild(button);

  return box;
}

// Does this species pass the map's search box and status filter?
function speciesPassesMapFilter(species, searchText, chosenStatus) {
  const names = (species.sci + ' ' + species.com).toLowerCase();
  if (names.indexOf(searchText) === -1) {
    return false;
  }
  if (chosenStatus !== '' && species.status !== chosenStatus) {
    return false;
  }
  return true;
}


// ---------- Draw one dot for every species ----------
// zoomToFit = true  -> zoom the map so all dots are visible
function drawMarkers(zoomToFit) {
  if (map === null) {
    return;                  // the map did not load
  }
  markerLayer.clearLayers();   // remove the old dots

  const searchText = document.getElementById('map-search').value.toLowerCase();
  const chosenStatus = document.getElementById('map-status').value;
  const list = getSpecies();
  const points = [];         // every location we drew
  let skipped = 0;           // species with a bad GPS text

  for (let i = 0; i < list.length; i++) {
    const species = list[i];

    if (speciesPassesMapFilter(species, searchText, chosenStatus) === false) {
      continue;              // skip this species
    }

    const gps = readGps(species.gps);
    if (gps === null) {
      skipped = skipped + 1;
      continue;
    }

    const dot = L.circleMarker(gps, {
      radius: 11,
      color: '#ffffff',
      weight: 2,
      fillColor: markerColor(species.status),
      fillOpacity: 0.9
    });
    dot.bindPopup(makePopup(species, i));

    // always show the location name next to the dot (for example "Kuching")
    if (species.loc) {
      dot.bindTooltip(species.loc, {
        permanent: true,
        direction: 'right',
        offset: [12, 0],
        className: 'loc-label'
      });
    }

    dot.addTo(markerLayer);
    points.push(gps);
  }

  // message under the map
  let message = 'Showing ' + points.length + ' species on the map.';
  if (skipped > 0) {
    message = message + ' ' + skipped + ' without a valid GPS location are not shown.';
  }
  document.getElementById('map-message').textContent = message;

  if (zoomToFit && points.length > 0) {
    map.fitBounds(L.latLngBounds(points), { padding: [50, 50], maxZoom: 16 });
  }
}


// ---------- Start ----------
// 'L' is the Leaflet library. If it is missing, the internet is probably down.
if (typeof L === 'undefined') {
  document.getElementById('map-message').textContent =
    'The map could not load. Check your internet connection and refresh the page.';
} else {
  createMap();
  drawMarkers(true);
}
