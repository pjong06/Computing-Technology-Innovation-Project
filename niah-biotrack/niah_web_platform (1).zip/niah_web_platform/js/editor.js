// editor.js - the Species record editor page.

drawMenu('editor.html');

let editIndex = -1;
let photo = PICTURE_BLANK;
let firstDate = '';
let firstWhen = '';
let obsId = '';
let reader = null;

// Shows the current photo in the preview box.
function showPhoto() {
  const preview = document.getElementById('photo-preview');
  preview.innerHTML = '';
  preview.appendChild(makeThumb(photo, 'Species photo'));
}

// Fills the form when the page opens: with the species to edit, or empty boxes for a new species.
function startEditor() {
  let wanted = readStorage(EDIT_KEY);
  if (wanted === null) {
    wanted = -1;
  }
  writeStorage(EDIT_KEY, -1);

  const list = getSpecies();
  if (wanted >= 0 && wanted < list.length) {
    editIndex = wanted;
    const species = list[wanted];
    document.getElementById('editor-title').innerHTML = 'Edit <span>species record</span>';
    document.getElementById('f-sci').value = species.sci;
    document.getElementById('f-com').value = species.com;
    document.getElementById('f-fam').value = species.fam;
    document.getElementById('f-status').value = species.status;
    document.getElementById('f-loc').value = species.loc;
    document.getElementById('f-gps').value = species.gps;
    document.getElementById('f-desc').value = species.desc;
    photo = species.photo;
    firstDate = species.firstDate;
    firstWhen = species.firstWhen;
    obsId = species.obsId || '';
  } else {
    editIndex = -1;
    document.getElementById('editor-title').innerHTML = 'Add <span>species record</span>';
    document.getElementById('f-status').value = 'Least Concern';
    photo = PICTURE_BLANK;
    firstDate = '';
    firstWhen = '';
    obsId = '';
  }
  showPhoto();
}

// Runs when the chosen photo file has been read. Keeps the photo and shows it in the preview.
function photoIsRead() {
  photo = reader.result;
  showPhoto();
}

// Starts reading the photo the user chose. Called when the file picker changes.
function previewPhoto(input) {
  const file = input.files[0];
  if (!file) {
    return;
  }
  reader = new FileReader();
  reader.onload = photoIsRead;
  reader.readAsDataURL(file);
}

// Checks the form, saves the species (new or edited), then goes back to the catalogue page.
function saveSpecies() {
  const sci = document.getElementById('f-sci').value.trim();
  if (sci === '') {
    showToast('Enter a scientific name');
    return;
  }

  const now = new Date();
  const species = {
    sci: sci,
    com: document.getElementById('f-com').value.trim(),
    fam: document.getElementById('f-fam').value.trim(),
    status: document.getElementById('f-status').value,
    loc: document.getElementById('f-loc').value.trim(),
    gps: document.getElementById('f-gps').value.trim(),
    desc: document.getElementById('f-desc').value.trim(),
    photo: photo,
    date: isoDate(now),
    when: whenText(now),
    firstDate: firstDate,
    firstWhen: firstWhen,
    obsId: obsId
  };
  if (editIndex === -1) {
    species.firstDate = isoDate(now);
    species.firstWhen = whenText(now);
  }

  const list = getSpecies();
  if (editIndex === -1) {
    list.push(species);
  } else {
    list[editIndex] = species;
  }

  const worked = writeStorage(SPECIES_KEY, list);
  if (worked === false) {
    showToast('Could not save. The photo may be too big.');
    return;
  }

  rememberToast('Species saved');
  location.href = 'species.html';
}

startEditor();
